
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">  
    <?php wp_head();?>
</head>
<body>
<header>
    <div class="header-container">
        <div class="logo-titulo">
            <h1>PS Nation</h1>
            <div class="logo">
                <a href="<?php echo home_url('/'); ?>"><img src="<?php echo get_template_directory_uri(); ?>/assets/images/screenshot.jpg" alt="logo"></a>
            </div>
        </div>
        <div class="menu-toggle" id="menu-toggle">
            ☰
        </div>
        <?php
        $arg = array(
            'theme_location' => 'main-menu',
            'container' => 'nav',
            'container_class' => 'main-nav',
            'menu_class' => 'menu-principal'
        );
        wp_nav_menu($arg);
        ?>
    </div>
</header>
    <main class="single-juego">
        <?php if (have_posts()) : while (have_posts()) : the_post(); ?>

            <article class="juego-detalle">
                <div class="juego-contenido">
                    <?php the_content(); ?>
                </div>
                <div class="juego-info">
                    <h1 class="juego-titulo"><?php the_title(); ?></h1>
                <div class="juego-img">
                    <?php
                    if (has_post_thumbnail()) {
                        the_post_thumbnail('large');
                    } else {
                        echo '<img src="' . get_template_directory_uri() . '/assets/images/default-game.jpg" alt="Juego">';
                    }
                    ?>
                </div>
                    <?php
                    $generos = get_the_terms(get_the_ID(), 'categoria-juego');
                    if (!empty($generos) && !is_wp_error($generos)) {
                        $nombres_generos = wp_list_pluck($generos, 'name');
                        echo '<p class="juego-genero"><strong>Género:</strong> ' . implode(', ', $nombres_generos) . '</p>';
                    }
                    ?>



                    <a href="<?php echo get_post_type_archive_link('videojuegos'); ?>" class="juego-link">
                        ← Volver a todos los juegos
                    </a>
                </div>
            </article>

        <?php endwhile; endif; ?>
    </main>
<?php get_footer();?>

