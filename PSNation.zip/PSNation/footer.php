<footer class="site-footer">
    <div class = 'sociales'>
        <h2>PS Nation</h2>
        <img src="<?php echo get_template_directory_uri(); ?>/assets/images/social.png" alt="Logo del footer">
    </div> 
    <div class="footer-container">

        <div class="footer-section">
            <h2>Acerca de</h2>
            <nav class="footer-links">
                <?php
                $paginas_legales = [
                    'Legislación sobre privacidad de datos',
                    'Documentos legales'
                ];
                foreach ($paginas_legales as $titulo) {
                    $pagina = get_page_by_title($titulo);
                    if ($pagina) {
                        echo '<a href="' . get_permalink($pagina->ID) . '">' . esc_html($pagina->post_title) . '</a>';
                    }
                }
                ?>
            </nav>
        </div>

        <div class="footer-section">
            <h2>Formulario de contactos</h2>
            <nav class="footer-links">
                <?php
                $paginas_contacto = [
                    'Formulario de contacto',
                    'Contactos'
                ];

                foreach ($paginas_contacto as $titulo) {
                    $pagina = get_page_by_title($titulo);
                    if ($pagina) {
                        echo '<a href="' . get_permalink($pagina->ID) . '">' . esc_html($pagina->post_title) . '</a>';
                    }
                }
                ?>
            </nav>
        </div>

    </div>
    <script>
    document.addEventListener('DOMContentLoaded', function() {
    const toggle = document.getElementById('menu-toggle');
    const menu = document.querySelector('.menu-principal');

    toggle.addEventListener('click', function() {
        menu.classList.toggle('show');
    });
    });
    </script>
    <?php wp_footer(); ?>
</footer>
</body>
</html>
