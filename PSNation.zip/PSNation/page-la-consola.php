<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php wp_head(); ?>
</head>
<header>
    <div class="header-container">
        <div class="logo-titulo">
            <h1>PS Nation</h1>
            <div class="logo">
                <a href="<?php echo home_url('/'); ?>"><img src="<?php echo get_template_directory_uri(); ?>/assets/images/screenshot.jpg" alt="logo"></a>
            </div>
        </div>
    <div class="menu-toggle" id="menu-toggle">
        ☰
    </div>
        <?php
        $arg = array(
            'theme_location' => 'main-menu',
            'container' => 'nav',
            'container_class' => 'main-nav',
            'menu_class' => 'menu-principal',
            'menu_id' => 'menu' 
        );
        wp_nav_menu($arg);
        ?>
    </div>
</header>

<main class="la-consola">
  <h1><?php the_title(); ?></h1>
  <h2>¡Aspectos técnicos que humillaron consolas!</h2>

  <div class="contenido">
    <?php the_content(); ?>
  </div>
</main>

<?php get_footer(); ?>

<script>
function toggleMenu() {
  document.getElementById('menu').classList.toggle('show');
}
</script>

</body>
</html>
