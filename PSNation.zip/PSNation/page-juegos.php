<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">  
    <?php wp_head();?>
</head>
<body>
<header>
    <div class="header-container">
        <div class="logo-titulo">
            <h1>PS Nation</h1>
            <div class="logo">
                <a href="<?php echo home_url('/'); ?>"><img src="<?php echo get_template_directory_uri(); ?>/assets/images/screenshot.jpg" alt="logo"></a>
            </div>
        </div>

        <div class="menu-toggle" id="menu-toggle">
            ☰
        </div>
        <?php
        $arg = array(
            'theme_location' => 'main-menu',
            'container' => 'nav',
            'container_class' => 'main-nav',
            'menu_class' => 'menu-principal'
        );
        wp_nav_menu($arg);
        ?>
    </div>
</header>

    <main>
        <h2>¡Todos nuestros juegos agrupados por géneros!</h2>
        <div class="juegos-genero">
            <div class="plataformas">
                <a href="<?php echo get_permalink( get_page_by_path( 'plataformas' ) ); ?>">
                    <img src="<?php echo get_template_directory_uri(); ?>/assets/images/plataformas.png" alt="logo">
                </a>
                <h3>Plataformas</h3>
            </div>
            <div class="horror">
                <a href="<?php echo get_permalink( get_page_by_path( 'horror' ) ); ?>">
                    <img src="<?php echo get_template_directory_uri(); ?>/assets/images/Terror.png" alt="logo">
                </a>                
                <h3>Horror</h3>
            </div>
            <div class="carreras">
                <a href="<?php echo get_permalink( get_page_by_path( 'carreras' ) ); ?>">
                    <img src="<?php echo get_template_directory_uri(); ?>/assets/images/carreras.png" alt="logo">
                </a>                 
                <h3>Carreras</h3>
            </div>            
            <div class="deportes">
                <a href="<?php echo get_permalink( get_page_by_path( 'deportes' ) ); ?>">
                    <img src="<?php echo get_template_directory_uri(); ?>/assets/images/deportes.png" alt="logo">
                </a>                
                <h3>Deportes</h3>
            </div>
            <div class="aventuras">
                <a href="<?php echo get_permalink( get_page_by_path( 'aventuras' ) ); ?>">
                    <img src="<?php echo get_template_directory_uri(); ?>/assets/images/aventura.png" alt="logo">
                </a>                 
                <h3>Aventuras</h3>
            </div>
        </div>
    </main>
    <?php get_footer();?>