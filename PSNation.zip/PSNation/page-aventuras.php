<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">  
    <?php wp_head();?>
</head>
<body>
<header>
    <div class="header-container">
        <div class="logo-titulo">
            <h1>PS Nation</h1>
            <div class="logo">
                <a href="<?php echo home_url('/'); ?>"><img src="<?php echo get_template_directory_uri(); ?>/assets/images/screenshot.jpg" alt="logo"></a>
            </div>
        </div>

        <div class="menu-toggle" id="menu-toggle">
            ☰
        </div>
        <?php
        $arg = array(
            'theme_location' => 'main-menu',
            'container' => 'nav',
            'container_class' => 'main-nav',
            'menu_class' => 'menu-principal'
        );
        wp_nav_menu($arg);
        ?>
    </div>
</header>

    <main>
        <h2>¡Las mejores aventuras se viven en la PS2!</h2>
        <?php
            get_template_part('template-parts/loop-mostrar-juegos-aventuras');
        ?>
    </main>
    <?php get_footer();?>