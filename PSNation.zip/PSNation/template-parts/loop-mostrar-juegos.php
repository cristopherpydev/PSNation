<?php

$args = array(
    'post_type' => 'videojuegos',
    'posts_per_page' => 6, 
    'orderby' => 'date',
    'order' => 'DESC',
);

$videojuegos_query = new WP_Query($args);

if ($videojuegos_query->have_posts()) : ?>
    <div class="juegos-grid">
        <?php while ($videojuegos_query->have_posts()) : $videojuegos_query->the_post(); ?>
            <div class="juego-tarjeta">
                <div class="juego-img">
                    <?php
                    if (has_post_thumbnail()) {
                        the_post_thumbnail('medium');
                    } else {
                        echo '<img src="' . get_template_directory_uri() . '/assets/images/default-game.jpg" alt="Juego">';
                    }
                    ?>
                </div>
                <h3 class="juego-titulo"><?php the_title(); ?></h3>
                <p class="juego-genero">
                    <strong>Género: </strong>
                    <?php
                    $categorias = get_the_terms(get_the_ID(), 'categoria-juego');
                    if ($categorias && !is_wp_error($categorias)) {
                        $lista = array();
                        foreach ($categorias as $categoria) {
                            $lista[] = $categoria->name;
                        }
                        echo implode(', ', $lista);
                    } else {
                        echo 'Sin categoría';
                    }
                    ?>
                </p>
                <a href="<?php the_permalink(); ?>" class="juego-link">Ver más</a>
            </div>
        <?php endwhile; ?>
    </div>
    <?php wp_reset_postdata(); ?>
<?php else : ?>
    <p>No hay videojuegos publicados aún.</p>
<?php endif; ?>
