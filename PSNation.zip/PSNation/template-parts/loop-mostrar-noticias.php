<?php
$args = array(
    'post_type'      => 'post', 
    'posts_per_page' => -1,      
    'orderby'        => 'date',
    'order'          => 'DESC',
);

$query = new WP_Query($args);
?>

<?php if ($query->have_posts()) : ?>
    <div class="noticias-grid">
        <?php while ($query->have_posts()) : $query->the_post(); ?>
            <article class="noticia-tarjeta">
                <div class="noticia-img">
                    <a href="<?php the_permalink(); ?>">
                        <?php 
                        if (has_post_thumbnail()) {
                            the_post_thumbnail('medium');
                        } else {
                            echo '<img src="' . get_template_directory_uri() . '/assets/images/default-news.jpg" alt="Noticia">';
                        }
                        ?>
                    </a>
                </div>

                <h3 class="noticia-titulo"><?php the_title(); ?></h3>

                <p class="noticia-genero">
                    <strong>Publicado:</strong> <?php echo get_the_date(); ?>
                </p>

                <p><?php echo wp_trim_words(get_the_excerpt(), 20, '...'); ?></p>

                <a class="noticia-link" href="<?php the_permalink(); ?>">Leer más</a>
            </article>
        <?php endwhile; ?>
    </div>

    <?php wp_reset_postdata(); ?>
<?php else : ?>
    <p>No hay noticias disponibles en este momento.</p>
<?php endif; ?>
