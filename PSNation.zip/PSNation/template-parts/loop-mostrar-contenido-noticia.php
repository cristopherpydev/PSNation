<?php if (have_posts()) : while (have_posts()) : the_post(); ?>

    <article class="noticia-detalle">
        <?php if (has_post_thumbnail()) : ?>
            <div class="noticia-img">
                <?php the_post_thumbnail('large'); ?>
            </div>
        <?php endif; ?>
        <div class="noticia-contenido">
            <div class="titulo-datos">
                <h1 class="noticia-titulo"><?php the_title(); ?></h1>
                <div class="noticia-meta">
                    <p><strong>Publicado el:</strong> <?php echo get_the_date(); ?></p>
                    <p><strong>Autor:</strong> <?php the_author(); ?></p>
                </div>
            </div>
            <div class="noticia-texto">
                <?php the_content(); ?>
            </div>
            <a href="<?php echo home_url('/noticias/'); ?>" class="volver-link">
                ← Volver a todas las noticias
            </a>
        </div>

    </article>

<?php endwhile; endif; ?>