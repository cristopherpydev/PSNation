<?php
$args = array(
    'post_type' => 'videojuegos',
    'posts_per_page' => -1, 
    'tax_query' => array(
        array(
            'taxonomy' => 'categoria-juego', 
            'field'    => 'slug',
            'terms'    => 'deportes', 
        ),
    ),
);

$query = new WP_Query($args);
?>

<?php if ($query->have_posts()): ?>
    <div class="juegos-grid">
        <?php while ($query->have_posts()): $query->the_post(); ?>
            <div class="juego-tarjeta">
                <div class="juego-img">
                    <?php
                    if (has_post_thumbnail()) {
                        the_post_thumbnail('medium');
                    } else {
                        echo '<img src="' . get_template_directory_uri() . '/assets/images/default-game.jpg" alt="Juego">';
                    }
                    ?>
                </div>

                <h3 class="juego-titulo"><?php the_title(); ?></h3>

                <?php
                    $generos = get_the_terms(get_the_ID(), 'categoria-juego');
                    if (!empty($generos) && !is_wp_error($generos)) {
                        $nombres_generos = wp_list_pluck($generos, 'name');
                        echo '<p class="juego-genero"><strong>Género:</strong> ' . implode(', ', $nombres_generos) . '</p>';
                    } else {
                        echo '<p class="juego-genero"><strong>Género:</strong> Sin categoría</p>';
                    }
                ?>


                <a class="juego-link" href="<?php the_permalink(); ?>">Más información</a>
            </div>
        <?php endwhile; ?>
    </div>
    <?php wp_reset_postdata(); ?>
<?php else: ?>
    <p>No hay juegos de deportes disponibles.</p>
<?php endif; ?>
