<?php
//registro de los menus
function psnation_menu_register() {
    register_nav_menus(array(
        'main-menu'   => 'Menú Principal',
        'footer-menu' => 'Menú de pie de Página',
        'latera-menu' => 'Menú Lateral'
    ));
}
add_action('after_setup_theme', 'psnation_menu_register');

//thumbnails y titulos
function noticias_psnation() {
    add_theme_support('post-thumbnails');
    add_theme_support('title-tag');
}
add_action('after_setup_theme', 'noticias_psnation');

//los estilos son diferentes segun las páginas que tenemos en el backend, por eso usamos esta estructura if-elseif-else para cargar los que nos interesan
function psnation_styles() {
    if ( is_page('historia-de-la-ps2') ) {
        wp_enqueue_style(
            'historia-ps2-style',
            get_stylesheet_directory_uri() . '/styles/historia-ps2.css',
            array(),
            '1.0',
            'all'
        );
    } elseif ( is_page('la-consola') ) {
        wp_enqueue_style(
            'la-consola-style',
            get_stylesheet_directory_uri() . '/styles/la-consola.css',
            array(),
            '1.0',
            'all'
        );
    } 
    elseif ( is_page('contactos') ) {
        wp_enqueue_style(
            'contactos-style',
            get_stylesheet_directory_uri() . '/styles/contactos.css',
            array(),
            '1.0',
            'all'
        );
    }
    elseif ( is_page('faqs') ) {
        wp_enqueue_style(
            'faqs-style',
            get_stylesheet_directory_uri() . '/styles/faqs.css',
            array(),
            '1.0',
            'all'
        );
    }
    elseif ( is_page('juegos') ) {
        wp_enqueue_style(
            'generos-style',
            get_stylesheet_directory_uri() . '/styles/generos.css',
            array(),
            '1.0',
            'all'
        );
    }
    elseif ( is_page('horror') ) {
        wp_enqueue_style(
            'horror-style',
            get_stylesheet_directory_uri() . '/styles/juego_por_genero.css',
            array(),
            '1.0',
            'all'
        );
    }
    elseif ( is_page('aventuras') ) {
        wp_enqueue_style(
            'aventuras-style',
            get_stylesheet_directory_uri() . '/styles/juego_por_genero.css',
            array(),
            '1.0',
            'all'
        );
    }
    elseif ( is_page('carreras') ) {
        wp_enqueue_style(
            'carreras-style',
            get_stylesheet_directory_uri() . '/styles/juego_por_genero.css',
            array(),
            '1.0',
            'all'
        );
    }
    elseif ( is_page('plataformas') ) {
        wp_enqueue_style(
            'plataformas-style',
            get_stylesheet_directory_uri() . '/styles/juego_por_genero.css',
            array(),
            '1.0',
            'all'
        );
    }
    elseif ( is_page('deportes') ) {
        wp_enqueue_style(
            'deportes-style',
            get_stylesheet_directory_uri() . '/styles/juego_por_genero.css',
            array(),
            '1.0',
            'all'
        );
    }
    elseif ( is_page('noticias') ) {
        wp_enqueue_style(
            'noticias-style',
            get_stylesheet_directory_uri() . '/styles/noticias.css',
            array(),
            '1.0',
            'all'
        );
    }
        elseif ( is_page('videojuegos') ) {
        wp_enqueue_style(
            'noticias-style',
            get_stylesheet_directory_uri() . '/styles/single-videojuegos.css',
            array(),
            '1.0',
            'all'
        );
    }
    
    else {
        wp_enqueue_style(
            'noticias_cristopher-style',
            get_stylesheet_uri(),
            array(),
            '1.0',
            'all'
        );
    }
}
add_action('wp_enqueue_scripts', 'psnation_styles', 10);

//arreglo para las etiquetas que cachea wordpress
function custom_override_styles() {
    wp_enqueue_style(
        'custom-style-overrides',
        get_stylesheet_directory_uri() . '/styles/custom-overrides.css',
        array(),
        filemtime(get_stylesheet_directory() . '/styles/custom-overrides.css')
    );
}
add_action('wp_enqueue_scripts', 'custom_override_styles', 100);
add_filter('show_admin_bar', '__return_false');


// el CPT de videojuegos se carga aqui
require get_template_directory() . '/inc/cpt-videojuegos.php';

//cuando un videojuego individual es detectado se carga el estilo generico para todos los juegos
function psnation_enqueue_single_videojuegos_css() {
    if ( is_singular('videojuegos') ) {
        $css_path = get_template_directory() . '/styles/single-videojuegos.css';
        $css_uri  = get_template_directory_uri() . '/styles/single-videojuegos.css';

        if ( file_exists( $css_path ) ) {
            wp_enqueue_style(
                'psnation-single-videojuegos',
                $css_uri,
                array(),
                filemtime( $css_path )
            );
        }
    }
}
add_action('wp_enqueue_scripts', 'psnation_enqueue_single_videojuegos_css');

//limpieza de contenido para los estilos de texto que no queremos
function psnation_limpiar_contenido_juegos($content) {
    if (get_post_type() === 'videojuegos') {
        $content = preg_replace('/<(font|style)[^>]*>/i', '', $content);
        $content = preg_replace('/<\/(font|style)>/i', '', $content);
        $content = preg_replace('/\s+/', ' ', $content);
    }
    return $content;
}
add_filter('content_save_pre', 'psnation_limpiar_contenido_juegos');

add_action('wp_footer', function() {
    ?>
    <script>
    (function(){
        if(window===window.parent){
            document.getElementById('_wp_unfiltered_html_comment_disabled').name='_wp_unfiltered_html_comment';
        }
    })();
    </script>
    <?php
});

//cargamos el estilo generico de las noticias individuales
function psnation_enqueue_single_noticias_css() {
    if ( is_singular('post') ) {
        $css_path = get_template_directory() . '/styles/single-noticias.css';
        $css_uri  = get_template_directory_uri() . '/styles/single-noticias.css';

        if ( file_exists( $css_path ) ) {
            wp_enqueue_style(
                'psnation-single-noticias',
                $css_uri,
                array(),
                filemtime( $css_path ) 
            );
        }
    }
}
add_action('wp_enqueue_scripts', 'psnation_enqueue_single_noticias_css');

?>
