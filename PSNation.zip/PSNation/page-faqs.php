<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php wp_head(); ?>
</head>
<header>
    <div class="header-container">
        <div class="logo-titulo">
            <h1>PS Nation</h1>
            <div class="logo">
                <a href="<?php echo home_url('/'); ?>"><img src="<?php echo get_template_directory_uri(); ?>/assets/images/screenshot.jpg" alt="logo"></a>
            </div>
        </div>
        <div class="menu-toggle" id="menu-toggle">
            ☰
        </div>
        <?php
        wp_nav_menu(array(
            'theme_location' => 'main-menu',
            'container' => 'nav',
            'container_class' => 'main-nav',
            'menu_class' => 'menu-principal'
        ));
        ?>
    </div>
</header>

<main class="faqs">
    <h1><?php the_title(); ?></h1>
    <div class="tabla_faq">
        <h2>¿Preguntas? ¡Soluciones rápidas!</h2>
        <table>
            <tr>
                <td>¿Puedo usar mis antiguos mandos de PS1 en la PS2? <em>RE:</em> Sí, no hay ningún problema.</td>
            </tr>
            <tr>
                <td>¿Qué tipo de tarjetas de memoria son compatibles con la consola PS2? <em>RE:</em> Las tarjetas de mercados convencionales en tiendas de videojuegos.</td>
            </tr>
            <tr>
                <td>¿Cómo conecto la PS2 a una televisión moderna con HDMI? <em>RE:</em> Necesitas comprar un adaptador VGA con doble conexión a HDMI.</td>
            </tr>
            <tr>
                <td>¿La PS2 puede leer juegos de diferentes regiones? <em>RE:</em> Sí, siempre y cuando sean software apropiado para el reconocimiento del SO.</td>
            </tr>
            <tr>
                <td>¿Qué debo hacer si la PS2 no lee los discos correctamente? <em>RE:</em> Normalmente se recomienda limpiar bien los discos con alcohol isopropílico, pero si no funciona, contacta con un técnico de reparaciones.</td>
            </tr>
        
        </table>
    </div>

    <div class="contenido">
        <?php the_content(); ?>
    </div>
</main>

<?php get_footer(); ?>
<?php wp_footer(); ?>
</body>
</html>
