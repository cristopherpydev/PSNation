<?php
/* Template Name: Contactos */
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>

<header>
    <div class="header-container">
        <div class="logo-titulo">
            <h1>PS Nation</h1>
            <div class="logo">
                <a href="<?php echo home_url('/'); ?>"><img src="<?php echo get_template_directory_uri(); ?>/assets/images/screenshot.jpg" alt="logo"></a>
            </div>
        </div>
        <div class="menu-toggle" id="menu-toggle">
            ☰
        </div>
        <?php
        wp_nav_menu(array(
            'theme_location' => 'main-menu',
            'container' => 'nav',
            'container_class' => 'main-nav',
            'menu_class' => 'menu-principal'
        ));
        ?>
    </div>
</header>

<main class="historia-ps2">
    <div class="presentacion_faq">
        <h1><?php the_title(); ?></h1>
        <h2>¿Alguna duda? No olvides visitar nuestra página de FAQs</h2>
        <div class="boton">
            <a class="boton-faq" href="<?php echo get_permalink( get_page_by_path( 'faqs' ) ); ?>">FAQs</a>
        </div>
        <div class="contenido">
            <?php the_content(); ?>
        </div>
    </div>
    <div class="formulario">
        <form action="" method="post">
            <div class="campos_identidad">
                <div class="apellido">
                    <label for="apellido">Apellido</label>
                    <input type="text" id="apellido" name="apellido" required placeholder="Escriba aquí su primer apellido">
                </div>

                <div class="nombre">
                    <label for="nombre">Nombre</label>
                    <input type="text" id="nombre" name="nombre" required placeholder="Escriba su nombre a continuación">
                </div>
            </div>

            <div class="correo">
                <label for="correo">Dirección de correo electrónico</label>
                <input type="email" id="correo" name="correo" required placeholder="email@tudominio.com">
            </div>

            <div class="texto">
                <label for="texto">Tu mensaje</label>
                <textarea name="texto" id="texto" placeholder="Introduce tu pregunta o mensaje" rows="5"></textarea>
            </div>

            <button type="submit">Enviar</button>
        </form>
    </div>
</main>

<?php get_footer(); ?>
<?php wp_footer(); ?>
</body>
</html>
